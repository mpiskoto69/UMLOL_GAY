package bank.storage;

public class UnMarshalingException extends Exception {
	  public UnMarshalingException(String message) {
	    super(message);
	  }
	  }