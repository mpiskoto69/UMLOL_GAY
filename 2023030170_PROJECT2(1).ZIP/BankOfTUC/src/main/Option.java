package main;

public interface Option {
	  String getLabel();
	    void execute();
}
